# Hospital-Management-System
This project is done using JAVA and Oracle
